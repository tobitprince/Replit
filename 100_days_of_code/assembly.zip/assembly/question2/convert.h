#ifndef CONVERT_H
#define CONVERT_H

void Convert76_0625(float* result);

#endif