#ifndef MULTIPLY_H
#define MULTIPLY_H

void MultiplyUnsigned(unsigned int multiplicand, 
                     unsigned int multiplier,
                     unsigned long long* product);

#endif