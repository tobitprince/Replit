#include <stdio.h>
#include "convert.h"

int main() {
    float result;
    Convert76_0625(&result);
    printf("Converted value: %f\n", result);
    return 0;
}