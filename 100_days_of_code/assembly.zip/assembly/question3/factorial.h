#ifndef FACTORIAL_H
#define FACTORIAL_H

int FactorialDiff(int a, int b);

#endif